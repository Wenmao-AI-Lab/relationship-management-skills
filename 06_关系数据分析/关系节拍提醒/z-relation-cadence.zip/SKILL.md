---
name: 关系维护节拍器
id: z-relation-cadence
description: 记录与每位重要之人的上次联系日期，按设定的维系节奏主动提醒「该关心了」，防止因忙碌冷落关系；数据本地存储。
version: 1.0.0
agent_created: true
platforms: ["AI助手", "claude", "cursor", "codex", "windsurf", "gemini", "copilot", "openclaw"]
category: 生活助手
slug: z-relation-cadence
displayName: 关系维护节拍器
summary: 记上次联系日，主动提醒该关心了，防关系冷掉。
license: MIT
disable: false
icon: icon.png
---

# 关系维护节拍器

## 触发词
「记一下今天联系了小李」「谁好久没联系了」「关系维护提醒」

## 运行流程
1. 记录：用户说「今天联系了XX」，写入 data/relations.json（name/last_contact/cadence）。
2. 查询：用户问「谁好久没联系」，扫描并标出距上次已超过设定节奏的人。
3. 提醒：会话开始可被动提示「有 N 位超过维系节奏，该关心了」。
4. 所有数据本地，不云传。

## 红线与注意
数据含人名/关系属敏感信息，必须本地、禁云传。
仅提醒不代发消息；不把关系数据用于其他用途。

## 适用边界
✅ 个人重要人脉的联系节奏管理。
❌ 不含客户 CRM / 销售跟进（属工作场景另一类）。

## 红蓝对抗记录
蓝军挑刺：① 敏感人名泄露 → P0 本地禁传；② 与关键日期库重复 → 本 Skill 管「行为节奏」而非固定日期，边界清晰；③ 误提醒骚扰 → cadence 可由用户调。结论：通过。

## 安装（多平台通用）
- AI助手: 复制本文件夹到 `~/.AI助手/skills/`
- Claude: 复制到 `~/.claude/skills/`
- Cursor: 复制到 `~/.cursor/skills/`
- 其他智能体客户端：放到对应 skills 目录即可。
- 数据均存于本技能 `data/` 相对路径，纯本地、不上云。
