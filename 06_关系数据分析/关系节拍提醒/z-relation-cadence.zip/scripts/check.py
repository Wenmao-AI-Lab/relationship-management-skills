import os, json
from datetime import date
SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def main():
    p = os.path.join(SKILL_DIR, "data", "relations.json")
    if not os.path.exists(p):
        print("暂无关系记录。"); return
    data = json.load(open(p, encoding="utf-8"))
    today = date.today()
    for r in data.get("relations", []):
        try:
            last = date.fromisoformat(r["last_contact"])
            cad = int(r.get("cadence", 30))
            gap = (today - last).days
            flag = "⚠️ 该联系了" if gap >= cad else "正常"
            print("%s | 距上次 %d 天 | 节奏 %d 天 | %s" % (r["name"], gap, cad, flag))
        except Exception:
            pass
if __name__ == "__main__":
    main()
