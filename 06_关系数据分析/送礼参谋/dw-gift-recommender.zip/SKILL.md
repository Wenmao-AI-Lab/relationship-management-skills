---
name: dw-gift-recommender
slug: dw-gift-recommender
displayName: 礼物推荐
description: 当用户说"送什么礼物/礼物推荐/送礼攻略/预算内"时使用。按对象/关系/预算/场合给得体礼物清单与避坑。
version: 1.0.0
category: 生活助手
platforms:
  - AI助手
    - Claude Code
    - Cursor
    - QClaw
    - ima
license: MIT
---

# 礼物推荐

节日临近，送啥都怕踩雷或显敷衍。

## 适用场景
- 按对象关系+预算筛
- 给 3-5 个选项+理由
- 提示避坑（如别送钟表）

## 核心能力
用
户
给
对
象
、
关
系
、
预
算
、
场
合
，
产
出
礼
物
清
单
（
含
价
位
与
心
意
点
）
，
并
标
注
文
化
避
讳
。

## 执行方式
本 skill 为工作流型，由 agent 按以下步骤执行，无需额外脚本：

用户："送女朋友生日礼物 500元" → 你给 5 选项+各自心意解读。

## 示例
None
