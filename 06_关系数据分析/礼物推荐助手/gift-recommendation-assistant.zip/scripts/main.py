#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
礼物推荐助手 - 送礼物不知道送什么？根据收礼人和预算给你精准推荐，送到心坎上
"""

import json
import sys


class GiftRecommendationAssistant:
    """生活工具助手类"""
    
    def __init__(self):
        self.name = "礼物推荐助手"
        self.category = "生活工具"
    
    def generate_checklist(self, user_info):
        """生成清单类内容"""
        checklist = {}
        
        if "gift-recommendation-assistant" == "home-cleaning-checklist":
            checklist = {
                "每日必做": [
                    "整理床铺",
                    "洗碗擦灶台",
                    "倒垃圾",
                    "随手归位物品"
                ],
                "每周打扫": [
                    "扫地拖地",
                    "擦桌子台面",
                    "卫生间清洁",
                    "换洗衣物",
                    "更换床品"
                ],
                "每月深度清洁": [
                    "擦玻璃",
                    "清理油烟机",
                    "冰箱清洁",
                    "空调滤网清洗",
                    "角落灰尘清理"
                ],
                "换季大扫除": [
                    "衣柜整理换季",
                    "窗帘清洗",
                    "厨卫深度除菌",
                    "杂物清理"
                ]
            }
        elif "gift-recommendation-assistant" == "clothes-storage-guide":
            checklist = {
                "整理前准备": [
                    "全部衣服拿出来分类",
                    "淘汰不穿的衣物",
                    "清洗待收纳衣物",
                    "准备收纳工具"
                ],
                "上衣收纳": [
                    "T恤折叠竖立放",
                    "衬衫挂起来防皱",
                    "毛衣折叠平放",
                    "外套用宽肩衣架"
                ],
                "裤子收纳": [
                    "牛仔裤折叠放抽屉",
                    "西裤挂起来",
                    "短裤可卷起来省空间"
                ],
                "小物件收纳": [
                    "内衣用分格收纳盒",
                    "袜子卷成球",
                    "丝巾领带挂起来"
                ]
            }
        elif "gift-recommendation-assistant" == "moving-organizer-assistant":
            checklist = {
                "搬家前4周": [
                    "确定搬家日期和方式",
                    "整理物品，断舍离",
                    "采购打包材料",
                    "通知相关单位变更地址"
                ],
                "搬家前2周": [
                    "开始打包不常用物品",
                    "办理水电燃气过户",
                    "预约搬家公司",
                    "贵重物品单独整理"
                ],
                "搬家前1天": [
                    "打包日常用品",
                    "确认搬家时间",
                    "准备搬家当天食物水",
                    "重要证件随身带"
                ],
                "搬家后": [
                    "检查物品是否完好",
                    "清洁新居所",
                    "逐步拆包整理",
                    "熟悉周边环境"
                ]
            }
        elif "gift-recommendation-assistant" == "road-trip-gear-list":
            checklist = {
                "证件类": [
                    "驾驶证、行驶证",
                    "身份证",
                    "保险单",
                    "车辆保养记录"
                ],
                "车辆装备": [
                    "备胎及换胎工具",
                    "拖车绳",
                    "搭电线",
                    "车载充气泵",
                    "反光背心"
                ],
                "生活用品": [
                    "换洗衣物",
                    "洗漱用品",
                    "充电宝",
                    "水杯水壶",
                    "零食干粮"
                ],
                "应急物品": [
                    "急救包",
                    "手电筒",
                    "多功能刀",
                    "雨伞雨衣",
                    "毯子"
                ],
                "导航娱乐": [
                    "手机支架",
                    "车载充电器",
                    "下载离线地图",
                    "音乐/播客列表"
                ]
            }
        elif "gift-recommendation-assistant" == "birthday-reminder-list":
            checklist = {
                "重要生日记录": [
                    "父母生日 - 准备礼物和祝福",
                    "爱人生日 - 安排惊喜或约会",
                    "孩子生日 - 准备生日派对",
                    "兄弟姐妹生日 - 送祝福",
                    "闺蜜/好兄弟生日 - 约饭庆祝"
                ],
                "其他重要日子": [
                    "结婚纪念日",
                    "恋爱纪念日",
                    "父母结婚纪念日",
                    "重要朋友的纪念日"
                ],
                "提前准备建议": [
                    "提前1个月：确定预算和礼物方向",
                    "提前2周：购买或定制礼物",
                    "提前1周：确认庆祝安排",
                    "提前1天：准备好礼物和祝福"
                ]
            }
        elif "gift-recommendation-assistant" == "family-archive-manager":
            checklist = {
                "证件类档案": [
                    "身份证（每人）",
                    "户口本",
                    "结婚证",
                    "房产证/购房合同",
                    "车辆登记证",
                    "学历学位证书"
                ],
                "财务类档案": [
                    "银行卡清单",
                    "保险保单",
                    "理财账户记录",
                    "重要发票收据"
                ],
                "医疗健康档案": [
                    "体检报告",
                    "病历资料",
                    "疫苗接种记录",
                    "过敏史记录"
                ],
                "家庭重要文件": [
                    "各种合同协议",
                    "重要信件",
                    "密码记录本（加密）",
                    "遗嘱等法律文件"
                ]
            }
        else:
            # 通用建议清单
            checklist = {
                "准备工作": [
                    "明确目标和需求",
                    "制定计划和时间安排",
                    "准备必要的工具材料",
                    "了解相关知识技巧"
                ],
                "执行步骤": [
                    "按计划逐步推进",
                    "遇到问题及时调整",
                    "保持耐心和专注",
                    "阶段性检查进度"
                ],
                "收尾工作": [
                    "检查完成质量",
                    "总结经验教训",
                    "整理归档",
                    "制定下次改进计划"
                ]
            }
        
        return checklist
    
    def generate_tips(self, user_info):
        """生成实用小贴士"""
        tips = []
        
        if "gift-recommendation-assistant" == "gift-recommendation-assistant":
            relation = user_info.get('relation', '朋友')
            budget = user_info.get('budget', 200)
            occasion = user_info.get('occasion', '生日')
            
            tips = [
                "送给" + str(relation) + "的" + str(occasion) + "礼物建议预算：" + str(budget) + "元左右",
                "选礼物原则：实用+心意+惊喜感",
                "提前了解对方喜好，投其所好最重要",
                "包装也是礼物的一部分，不要忽略",
                "手写贺卡更显诚意"
            ]
            
            if relation == '父母':
                tips.extend([
                    "实用型礼物最受欢迎（按摩仪、保健品等）",
                    "陪伴是最好的礼物，记得多回家看看",
                    "可以选择改善生活品质的家电"
                ])
            elif relation == '恋人':
                tips.extend([
                    "用心准备比价格更重要",
                    "可以选择有纪念意义的礼物",
                    "搭配惊喜效果更好"
                ])
        elif "gift-recommendation-assistant" == "plant-care-assistant":
            tips = [
                "浇水原则：见干见湿，不要天天浇",
                "大多数植物喜欢散射光，避免暴晒",
                "注意通风，防止病虫害",
                "定期转盆，让植物均匀受光",
                "施肥薄肥勤施，避免烧根"
            ]
        elif "gift-recommendation-assistant" == "first-aid-guide":
            tips = [
                "家庭急救包必备：碘伏、纱布、创可贴、体温计、镊子、剪刀",
                "记住急救电话：120",
                "遇到紧急情况保持冷静",
                "先确保环境安全，再施救",
                "严重情况第一时间送医"
            ]
        elif "gift-recommendation-assistant" == "recipe-conversion-tool":
            tips = [
                "食材换算按比例缩放即可",
                "调料建议先少放再调整",
                "烘焙类配方建议用电子秤精确称量",
                "不同烤箱温度有差异，注意观察",
                "做多了可以分装冷冻保存"
            ]
        elif "gift-recommendation-assistant" == "food-storage-guide":
            tips = [
                "叶菜类用厨房纸包裹放冰箱可延长保鲜",
                "肉类分装冷冻，吃多少拿多少",
                "葱姜蒜可以切碎冷冻保存",
                "面包放冷冻保存时间更长",
                "注意生熟分开，避免交叉污染"
            ]
        elif "gift-recommendation-assistant" == "pet-feeding-guide":
            tips = [
                "选择正规品牌的主粮，注意查看配料表",
                "定时定量喂食，不要过度投喂",
                "保证充足清洁的饮水",
                "定期驱虫和接种疫苗",
                "注意观察宠物精神状态和排便情况"
            ]
        elif "gift-recommendation-assistant" == "appliance-shopping-assistant":
            tips = [
                "先明确需求和预算，不被营销话术带偏",
                "关注核心功能，附加功能按需选择",
                "多看真实用户评价，尤其差评",
                "关注能效等级，长期使用更省钱",
                "考虑售后服务和保修政策"
            ]
        elif "gift-recommendation-assistant" == "housework-division-assistant":
            tips = [
                "按擅长和时间分配，不是完全对半分",
                "制定家务清单和轮值表",
                "可以花钱外包不想做的家务",
                "互相体谅，感谢对方的付出",
                "家务不是某一个人的事"
            ]
        else:
            tips = [
                "提前规划，事半功倍",
                "定期整理，保持习惯",
                "工欲善其事，必先利其器",
                "循序渐进，不要追求一步到位",
                "适合自己的才是最好的"
            ]
        
        return tips
    
    def run(self, user_input):
        """主执行函数"""
        user_info = {
            "name": user_input.get("name", "朋友"),
            "scene": user_input.get("scene", "日常"),
            "budget": user_input.get("budget", 0),
            "preference": user_input.get("preference", "简洁实用"),
            "goal": user_input.get("goal", "获得礼物推荐助手建议")
        }
        
        # 生成清单
        checklist = self.generate_checklist(user_info)
        
        # 生成小贴士
        tips = self.generate_tips(user_info)
        
        result = {
            "title": "您的专属礼物推荐助手方案",
            "user_info": user_info,
            "checklist": checklist,
            "practical_tips": tips,
            "recommendations": [
                "根据自己的实际情况调整方案",
                "先从简单的开始，逐步完善",
                "坚持执行，养成习惯",
                "定期复盘优化"
            ]
        }
        
        return result


def main():
    """主函数"""
    if len(sys.argv) > 1:
        try:
            user_input = json.loads(sys.argv[1])
        except:
            user_input = {"scene": sys.argv[1]}
    else:
        user_input = {
            "name": "测试用户",
            "scene": "日常使用",
            "goal": "了解礼物相关知识"
        }
    
    assistant = GiftRecommendationAssistant()
    result = assistant.run(user_input)
    
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return result


if __name__ == "__main__":
    main()
