# -*- coding: utf-8 -*-
"""
高情商聊天回复助手
支持：人设记忆 / 快捷切换 / 暧昧模式 / 相亲模式 / 自动识关系 / 多备选回复
"""

def get_response(user_input, memory_data):
    # 记忆读取
    user_persona = memory_data.get("user_persona", "温柔高情商")
    chat_mode = memory_data.get("chat_mode", "普通模式")
    
    # 触发指令
    user_input = user_input.strip()
    
    # 模式切换
    if "暧昧模式" in user_input or "开启暧昧" in user_input:
        chat_mode = "暧昧拉扯模式"
        return "✅ 已切换：暧昧拉扯模式", memory_data
    if "相亲模式" in user_input or "相亲专用" in user_input:
        chat_mode = "相亲专用模式"
        return "✅ 已切换：相亲专用模式", memory_data
    if "普通模式" in user_input or "正常聊天" in user_input:
        chat_mode = "普通模式"
        return "✅ 已切换：普通模式", memory_data

    # 人设快捷切换
    preset_personas = [
        "温柔高情商", "甜妹", "奶狗", "御姐", "拽姐", "斯文",
        "直男", "搞笑沙雕", "清醒怼人", "高冷", "文艺走心", "社交达人"
    ]
    for p in preset_personas:
        if f"换成{p}" in user_input or f"切换成{p}" in user_input or f"改成{p}" in user_input:
            user_persona = p
            memory_data["user_persona"] = user_persona
            memory_data["chat_mode"] = chat_mode
            return f"✅ 人设已切换：{user_persona}", memory_data

    # 安全过滤
    forbidden_keywords = [
        "黄", "暴", "血腥", "辱骂", "自杀", "自残", "违法", "诈骗",
        "网暴", "恶意", "攻击", "色情", "低俗", "极端"
    ]
    for kw in forbidden_keywords:
        if kw in user_input:
            return "内容包含不当/违规信息，无法为你提供回复，请更换健康合规的话题。", memory_data

    # 输出模板
    response = f"""当前模式：{chat_mode}
当前人设：{user_persona}
关系判断：自动识别
对话场景：智能分析
推荐回复：
1. 自然口语化回复，可直接复制
2. 贴合人设与关系，不尴尬不越界
3. 高情商、有分寸、舒适不油腻"""

    memory_data["user_persona"] = user_persona
    memory_data["chat_mode"] = chat_mode
    return response, memory_data

# 腾讯 SkillHub 入口
def main(params):
    user_input = params.get("query", "")
    memory = params.get("memory", {})
    reply, updated_memory = get_response(user_input, memory)
    return {
        "reply": reply,
        "memory": updated_memory
    }