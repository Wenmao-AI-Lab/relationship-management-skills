# 衍生版本说明

- 原项目：[boshi-xixixi/traeskill]()
- 原文件：`.trae/Skills/.agents/skills/gtm-enterprise-account-planning/SKILL.md`
- 固定提交：`9cf38e632bdfb9d91a965140ffcbdac8e45659b1`
- 许可证：`MIT`，全文见 `LICENSE.md`
- 修改内容：语义化 slug、中文业务名称、发布接口元数据和帮助入口。
- 未删除原许可证义务，也未扩大原 Skill 的能力声明。
