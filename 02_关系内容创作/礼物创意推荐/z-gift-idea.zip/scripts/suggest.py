import os, json, sys
SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def load():
    p = os.path.join(SKILL_DIR, "data", "gift-templates.json")
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)
def main():
    rel = sys.argv[1] if len(sys.argv) > 1 else "朋友"
    data = load()
    ideas = data.get("relations", {}).get(rel, data.get("relations", {}).get("朋友", []))
    print("【%s】礼物灵感（仅供参考，请自行比价）：" % rel)
    for i in ideas:
        print(" -", i)
    print("\n祝福语模板：")
    for k, v in data.get("blessings", {}).items():
        for line in v[:1]:
            print(" [%s] %s" % (k, line))
if __name__ == "__main__":
    main()
